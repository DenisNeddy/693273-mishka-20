Папка для файлов препроцессора Sass.

https://sass-lang.com

--

Структура файлов:

sass/
| - style.scss
| - [другие *.scss файлы]
